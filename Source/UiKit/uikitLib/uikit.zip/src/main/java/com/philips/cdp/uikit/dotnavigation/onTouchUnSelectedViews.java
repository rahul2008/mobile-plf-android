package com.philips.cdp.uikit.dotnavigation;

import android.view.View;

/**
 * (C) Koninklijke Philips N.V., 2015.
 * All rights reserved.
 */
public interface onTouchUnSelectedViews {

    void onClickUnSelectedView(View view, int position);
}
